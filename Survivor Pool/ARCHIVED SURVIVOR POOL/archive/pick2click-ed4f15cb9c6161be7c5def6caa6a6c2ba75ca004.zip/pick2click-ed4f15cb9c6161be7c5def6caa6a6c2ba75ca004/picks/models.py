from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Player(models.Model):
    name = models.CharField(max_length=100)
    team = models.CharField(max_length=50)
    position = models.CharField(max_length=10)
    is_custom = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class DailyPick(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    player = models.ForeignKey(Player, on_delete=models.CASCADE)
    winning_player = models.ForeignKey(Player, on_delete=models.SET_NULL, null=True, related_name='winning_picks')
    is_winner = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    last_modified = models.DateTimeField(auto_now=True)
    modified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='modified_picks')

    class Meta:
        unique_together = ['user', 'date']

    def __str__(self):
        return f"{self.user.username}'s pick for {self.date}: {self.player.name}"

class GameData(models.Model):
    date = models.DateField(unique=True)
    opponent = models.CharField(max_length=100)
    location = models.CharField(max_length=100)  # Home or Away
    orioles_score = models.IntegerField(null=True, blank=True)
    opponent_score = models.IntegerField(null=True, blank=True)
    is_win = models.BooleanField(default=False)
    
    def __str__(self):
        result = "W" if self.is_win else "L"
        return f"{self.date}: BAL {self.orioles_score}-{self.opponent_score} {self.opponent} ({result})"

class PickAuditLog(models.Model):
    pick = models.ForeignKey(DailyPick, on_delete=models.CASCADE)
    modified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action = models.CharField(max_length=50)  # 'create', 'update', 'delete'
    old_value = models.JSONField(null=True)
    new_value = models.JSONField(null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.action} on {self.pick} by {self.modified_by}"