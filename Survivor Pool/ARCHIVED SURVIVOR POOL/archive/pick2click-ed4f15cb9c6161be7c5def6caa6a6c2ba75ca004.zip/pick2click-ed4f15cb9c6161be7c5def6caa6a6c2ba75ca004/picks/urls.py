from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView, LoginView

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('make-pick/', views.make_pick, name='make-pick'),
    path('admin-controls/', views.admin_controls, name='admin-controls'),
    path('history/', views.history, name='history'),
    path('history/<int:year>/<int:month>/<int:day>/', views.day_detail, name='day_detail'),
    path('export-history/', views.export_history, name='export-history'),
    path('admin/run-migrations/', views.run_migrations, name='run_migrations'),
    path('admin/populate-players/', views.populate_players, name='populate-players'),
    path('admin/scrape-game-data/', views.scrape_game_data, name='scrape-game-data'),
    path('make-admin/<str:username>/', views.make_admin, name='make-admin'),
    path('admin/debug-player-stats/', views.debug_player_stats, name='debug-player-stats'),
    path('debug-info/', views.debug_info, name='debug_info'),
    path('test-database/', views.test_database, name='test_database'),
    path('health/', views.health_check, name='health_check'),
    path('debug-dashboard/', views.debug_dashboard, name='debug_dashboard'),
]