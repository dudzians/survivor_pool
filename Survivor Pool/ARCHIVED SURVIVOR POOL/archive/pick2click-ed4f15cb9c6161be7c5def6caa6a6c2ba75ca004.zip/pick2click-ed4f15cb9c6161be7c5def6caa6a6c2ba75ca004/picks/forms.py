from django import forms
from django.utils import timezone
from zoneinfo import ZoneInfo
from .models import Player, DailyPick
from django.core.exceptions import ValidationError

class DailyPickForm(forms.ModelForm):
    use_custom_player = forms.BooleanField(required=False)
    custom_player_name = forms.CharField(required=False)
    
    class Meta:
        model = DailyPick
        fields = ['player']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make the player field not required as it might be a custom player
        self.fields['player'].required = False
        
        # Get all players already picked today
        est_now = timezone.now().astimezone(ZoneInfo("America/New_York"))
        today = est_now.date()
        picked_players = DailyPick.objects.filter(date=today).values_list('player_id', flat=True)
        
        # Update the queryset to only show available players
        self.fields['player'].queryset = Player.objects.filter(
            is_custom=False
        ).exclude(
            id__in=picked_players
        ).order_by('name')

    def clean(self):
        cleaned_data = super().clean()
        est_now = timezone.now().astimezone(ZoneInfo("America/New_York"))
        today = est_now.date()
        
        # Check if it's past the cutoff time (7:05 PM EST)
        cutoff_time = timezone.datetime.combine(
            today,
            timezone.datetime.strptime("19:05", "%H:%M").time()
        ).replace(tzinfo=ZoneInfo("America/New_York"))
        
        if est_now > cutoff_time:
            raise ValidationError("It's past 7:05 PM EST. You can no longer make picks for today.")
        
        use_custom_player = cleaned_data.get('use_custom_player')
        custom_player_name = cleaned_data.get('custom_player_name', '').strip()
        player = cleaned_data.get('player')
        
        # Validate player selection
        if use_custom_player:
            if not custom_player_name:
                raise ValidationError("Please enter a custom player name.")
                
            # Check if this custom player name was already picked today
            existing_custom_pick = DailyPick.objects.filter(
                date=today,
                player__name__iexact=custom_player_name
            ).exists()
            
            if existing_custom_pick:
                raise ValidationError(f"{custom_player_name} has already been picked today.")
        else:
            if not player:
                raise ValidationError("Please select a player.")
            
            # Check if player was already picked
            if DailyPick.objects.filter(date=today, player=player).exists():
                raise ValidationError(f"{player.name} has already been picked today.")
        
        return cleaned_data

class PlayerForm(forms.ModelForm):
    class Meta:
        model = Player
        fields = ['name', 'team', 'position']
        
    def clean_name(self):
        name = self.cleaned_data['name'].strip()
        if not name:
            raise ValidationError("Player name cannot be empty.")
        return name
        
    def clean_team(self):
        team = self.cleaned_data['team'].strip()
        if not team:
            raise ValidationError("Team name cannot be empty.")
        return team
        
    def clean_position(self):
        position = self.cleaned_data['position'].strip()
        if not position:
            raise ValidationError("Position cannot be empty.")
        return position

class DateSelectionForm(forms.Form):
    date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        help_text="Select a date to view or update picks"
    )
    
    def clean_date(self):
        selected_date = self.cleaned_data['date']
        est_now = timezone.now().astimezone(ZoneInfo("America/New_York"))
        
        # Prevent selecting future dates
        if selected_date > est_now.date():
            raise ValidationError("Cannot select future dates.")
            
        return selected_date