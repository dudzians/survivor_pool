from django.core.management.base import BaseCommand
from picks.models import Player

class Command(BaseCommand):
    help = 'Updates the player database with current Orioles roster'

    def handle(self, *args, **kwargs):
        # Clear existing non-custom players
        Player.objects.filter(is_custom=False).delete()
        
        orioles_players = [
            # Pitchers
            {'name': 'Keegan Akin', 'position': 'P', 'team': 'BAL'},
            {'name': 'Bryan Baker', 'position': 'P', 'team': 'BAL'},
            {'name': 'Félix Bautista', 'position': 'P', 'team': 'BAL'},
            {'name': 'Kyle Bradish', 'position': 'P', 'team': 'BAL'},
            {'name': 'Yennier Cano', 'position': 'P', 'team': 'BAL'},
            {'name': 'Dean Kremer', 'position': 'P', 'team': 'BAL'},
            {'name': 'Grayson Rodriguez', 'position': 'P', 'team': 'BAL'},
            {'name': 'Tyler Wells', 'position': 'P', 'team': 'BAL'},
            
            # Catchers
            {'name': 'Adley Rutschman', 'position': 'C', 'team': 'BAL'},
            {'name': 'Gary Sánchez', 'position': 'C', 'team': 'BAL'},
            
            # Infielders
            {'name': 'Gunnar Henderson', 'position': 'IF', 'team': 'BAL'},
            {'name': 'Jackson Holliday', 'position': 'IF', 'team': 'BAL'},
            {'name': 'Jorge Mateo', 'position': 'IF', 'team': 'BAL'},
            {'name': 'Ryan Mountcastle', 'position': 'IF', 'team': 'BAL'},
            {'name': "Ryan O'Hearn", 'position': 'IF', 'team': 'BAL'},
            {'name': 'Jordan Westburg', 'position': 'IF', 'team': 'BAL'},
            
            # Outfielders
            {'name': 'Colton Cowser', 'position': 'OF', 'team': 'BAL'},
            {'name': 'Heston Kjerstad', 'position': 'OF', 'team': 'BAL'},
            {'name': 'Cedric Mullins', 'position': 'OF', 'team': 'BAL'},
            {'name': "Tyler O'Neill", 'position': 'OF', 'team': 'BAL'},
        ]
        
        for player_data in orioles_players:
            Player.objects.create(
                name=player_data['name'],
                team=player_data['team'],
                position=player_data['position'],
                is_custom=False
            )
        
        self.stdout.write(self.style.SUCCESS(f'Successfully added {len(orioles_players)} Orioles players'))