from django.core.management.base import BaseCommand
from picks.models import Player

class Command(BaseCommand):
    help = 'Populate the database with Baltimore Orioles players'

    def handle(self, *args, **options):
        # List of Orioles players with their positions
        orioles_players = [
            # Catchers
            {'name': 'Adley Rutschman', 'team': 'Baltimore Orioles', 'position': 'C'},
            {'name': 'James McCann', 'team': 'Baltimore Orioles', 'position': 'C'},
            
            # Infielders
            {'name': 'Ryan Mountcastle', 'team': 'Baltimore Orioles', 'position': '1B'},
            {'name': 'Ryan O\'Hearn', 'team': 'Baltimore Orioles', 'position': '1B'},
            {'name': 'Jorge Mateo', 'team': 'Baltimore Orioles', 'position': 'SS'},
            {'name': 'Gunnar Henderson', 'team': 'Baltimore Orioles', 'position': 'SS/3B'},
            {'name': 'Jordan Westburg', 'team': 'Baltimore Orioles', 'position': '2B/3B'},
            {'name': 'Ramón Urías', 'team': 'Baltimore Orioles', 'position': '3B'},
            {'name': 'Connor Norby', 'team': 'Baltimore Orioles', 'position': '2B'},
            
            # Outfielders
            {'name': 'Austin Hays', 'team': 'Baltimore Orioles', 'position': 'LF'},
            {'name': 'Cedric Mullins', 'team': 'Baltimore Orioles', 'position': 'CF'},
            {'name': 'Anthony Santander', 'team': 'Baltimore Orioles', 'position': 'RF'},
            {'name': 'Heston Kjerstad', 'team': 'Baltimore Orioles', 'position': 'OF'},
            {'name': 'Colton Cowser', 'team': 'Baltimore Orioles', 'position': 'OF'},
            
            # Designated Hitter
            {'name': 'Kyle Stowers', 'team': 'Baltimore Orioles', 'position': 'DH/OF'},
            
            # Starting Pitchers
            {'name': 'Corbin Burnes', 'team': 'Baltimore Orioles', 'position': 'SP'},
            {'name': 'Grayson Rodriguez', 'team': 'Baltimore Orioles', 'position': 'SP'},
            {'name': 'Kyle Bradish', 'team': 'Baltimore Orioles', 'position': 'SP'},
            {'name': 'Dean Kremer', 'team': 'Baltimore Orioles', 'position': 'SP'},
            {'name': 'John Means', 'team': 'Baltimore Orioles', 'position': 'SP'},
            {'name': 'Tyler Wells', 'team': 'Baltimore Orioles', 'position': 'SP'},
            
            # Relief Pitchers
            {'name': 'Félix Bautista', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Yennier Cano', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Danny Coulombe', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Cionel Pérez', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Keegan Akin', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Bryan Baker', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Mike Baumann', 'team': 'Baltimore Orioles', 'position': 'RP'},
            {'name': 'Jacob Webb', 'team': 'Baltimore Orioles', 'position': 'RP'},
        ]
        
        # Count of players added and skipped
        added_count = 0
        skipped_count = 0
        
        # Add players to the database
        for player_data in orioles_players:
            player, created = Player.objects.get_or_create(
                name=player_data['name'],
                defaults={
                    'team': player_data['team'],
                    'position': player_data['position'],
                    'is_custom': False
                }
            )
            
            if created:
                added_count += 1
                self.stdout.write(self.style.SUCCESS(f'Added player: {player.name}'))
            else:
                skipped_count += 1
                self.stdout.write(self.style.WARNING(f'Player already exists: {player.name}'))
        
        self.stdout.write(self.style.SUCCESS(f'Successfully added {added_count} players. Skipped {skipped_count} existing players.')) 