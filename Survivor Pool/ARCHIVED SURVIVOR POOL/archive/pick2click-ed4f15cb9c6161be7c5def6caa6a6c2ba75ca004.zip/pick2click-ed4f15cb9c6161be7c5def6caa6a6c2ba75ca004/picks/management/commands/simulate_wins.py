from django.core.management.base import BaseCommand
from picks.models import DailyPick
import random

class Command(BaseCommand):
    help = 'Simulates random wins for testing'

    def handle(self, *args, **kwargs):
        picks = DailyPick.objects.all()
        for pick in picks:
            pick.is_winner = random.choice([True, False])
            pick.save()
        
        self.stdout.write(self.style.SUCCESS(f'Successfully simulated wins for {picks.count()} picks'))