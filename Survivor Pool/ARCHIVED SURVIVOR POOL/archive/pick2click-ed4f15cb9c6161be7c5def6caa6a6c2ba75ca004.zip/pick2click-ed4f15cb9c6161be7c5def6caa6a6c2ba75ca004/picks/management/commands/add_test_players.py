from django.core.management.base import BaseCommand
from picks.models import Player

class Command(BaseCommand):
    help = 'Adds test players to the database'

    def handle(self, *args, **kwargs):
        test_players = [
            {'name': 'Mike Trout', 'team': 'LAA', 'position': 'OF'},
            {'name': 'Shohei Ohtani', 'team': 'LAD', 'position': 'DH'},
            {'name': 'Juan Soto', 'team': 'NYY', 'position': 'OF'},
            {'name': 'Mookie Betts', 'team': 'LAD', 'position': 'OF'},
            {'name': 'Ronald Acuña Jr.', 'team': 'ATL', 'position': 'OF'},
        ]

        for player_data in test_players:
            Player.objects.get_or_create(
                name=player_data['name'],
                defaults={
                    'team': player_data['team'],
                    'position': player_data['position'],
                    'is_custom': False
                }
            )
        
        self.stdout.write(self.style.SUCCESS('Successfully added test players'))