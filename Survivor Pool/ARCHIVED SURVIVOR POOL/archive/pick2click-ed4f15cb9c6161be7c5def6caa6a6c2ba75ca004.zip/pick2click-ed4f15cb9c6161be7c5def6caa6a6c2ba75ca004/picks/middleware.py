import logging
import traceback
from django.db import connection, OperationalError, DatabaseError
from django.http import HttpResponse
from django.template.response import TemplateResponse
from django.contrib import messages

logger = logging.getLogger('picks')

class DatabaseConnectionMiddleware:
    """
    Middleware to check database connection and handle errors gracefully.
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        logger.info("DatabaseConnectionMiddleware initialized")
    
    def __call__(self, request):
        # Check if the database is accessible
        try:
            # Skip database check for static files, admin, etc.
            if request.path.startswith('/static/') or request.path.startswith('/media/') or request.path == '/favicon.ico':
                return self.get_response(request)
                
            logger.debug(f"Checking database connection for path: {request.path}")
            
            # Test database connection
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                
            # If we get here, the database is accessible
            logger.debug("Database connection successful")
            response = self.get_response(request)
            return response
            
        except (OperationalError, DatabaseError) as e:
            # Log the database error
            logger.error(f"Database connection error: {str(e)}")
            logger.error(f"Request path: {request.path}")
            logger.error(f"Request user: {request.user}")
            logger.error(f"Database settings: ENGINE={connection.settings_dict.get('ENGINE')}, NAME={connection.settings_dict.get('NAME')}")
            logger.error(traceback.format_exc())
            
            # Only handle HTML responses
            if 'text/html' in request.META.get('HTTP_ACCEPT', ''):
                # Add a message for the user
                messages.error(request, "We're having trouble connecting to our database. Please try again later.")
                
                # For API endpoints, return a JSON response
                if request.path.startswith('/api/'):
                    return HttpResponse(
                        '{"error": "Database connection error. Please try again later."}',
                        content_type='application/json',
                        status=503
                    )
                
                # For regular pages, let the view handle it
                # The view will show a friendly error page
                request.database_error = True
                response = self.get_response(request)
                return response
            
            # For non-HTML requests, return a service unavailable response
            return HttpResponse(
                "Database connection error. Please try again later.",
                content_type='text/plain',
                status=503
            )
        
        except Exception as e:
            # Log other unexpected errors
            logger.error(f"Unexpected error in database middleware: {str(e)}")
            logger.error(f"Request path: {request.path}")
            logger.error(f"Request user: {request.user}")
            logger.error(traceback.format_exc())
            
            # Let the view handle it
            return self.get_response(request) 