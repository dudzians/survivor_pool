from django.contrib import admin
from .models import Player, DailyPick
from django.utils import timezone
from zoneinfo import ZoneInfo

@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ('name', 'team', 'position', 'is_custom')
    list_filter = ('team', 'position', 'is_custom')
    search_fields = ('name', 'team')

@admin.register(DailyPick)
class DailyPickAdmin(admin.ModelAdmin):
    list_display = ('user', 'player', 'date', 'is_winner', 'created_at_est')
    list_filter = ('date', 'is_winner', 'user')
    search_fields = ('user__username', 'player__name')

    def created_at_est(self, obj):
        return obj.created_at.astimezone(ZoneInfo("America/New_York"))
    created_at_est.short_description = 'Created (EST)'