from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Count, Q, F, ExpressionWrapper, FloatField, Case, When, Value
from django.utils import timezone
from django.db.models.functions import Cast
from django.urls import reverse
from django.http import HttpResponse, JsonResponse
from django.db.models import Prefetch
from django.db import IntegrityError
from django.core.exceptions import ValidationError
from datetime import datetime, date
from calendar import monthcalendar
from zoneinfo import ZoneInfo
import csv
from django.core.management import call_command
import requests
from bs4 import BeautifulSoup
import os
import json
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.template.defaulttags import register
import re
import time
import random

from .models import Player, DailyPick, PickAuditLog, GameData
from .forms import DailyPickForm
from .utils import get_est_time, clean_player_name, validate_unique_player, get_user_stats

# Custom template filter to calculate overall player statistics
@register.filter
def map_player_stats(user_stats_list):
    # Initialize dictionaries to track overall stats
    player_times_chosen = {}
    player_wins = {}
    
    # Iterate through all users' stats
    for user_data in user_stats_list:
        stats = user_data.get('stats', [])
        for stat in stats:
            player_name = stat.get('player_name')
            times_chosen = int(stat.get('times_chosen', 0))
            wins = int(stat.get('wins', 0))
            
            # Add to overall counts
            if player_name not in player_times_chosen:
                player_times_chosen[player_name] = 0
                player_wins[player_name] = 0
            
            player_times_chosen[player_name] += times_chosen
            player_wins[player_name] += wins
    
    # Calculate overall stats for each player
    overall_stats = []
    for player_name, times_chosen in player_times_chosen.items():
        wins = player_wins.get(player_name, 0)
        win_percentage = (wins / times_chosen) * 100 if times_chosen > 0 else 0
        
        overall_stats.append({
            'player_name': player_name,
            'times_chosen': times_chosen,
            'wins': wins,
            'win_percentage': f"{win_percentage:.1f}%"
        })
    
    # Sort by times chosen (descending)
    overall_stats.sort(key=lambda x: x['times_chosen'], reverse=True)
    
    return overall_stats

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Account created successfully!')
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'users/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'users/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    """Dashboard view showing today's picks and user statistics."""
    import logging
    import traceback
    from django.db import connection, OperationalError, DatabaseError
    
    logger = logging.getLogger(__name__)
    logger.info(f"Starting dashboard view for user: {request.user.username}")
    
    try:
        # Test database connection first
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            logger.info("Database connection test successful")
        
        # Get current date
        est_now = get_est_time()
        today = est_now.date()
        logger.info(f"Current date (EST): {today}")
        
        # Get today's picks
        logger.info("Fetching today's picks")
        today_picks = DailyPick.objects.filter(date=today).select_related('user', 'player').order_by('created_at')
        logger.info(f"Found {today_picks.count()} picks for today")
        
        # Get current user's pick for today
        logger.info("Checking current user's pick")
        current_user_pick = DailyPick.objects.filter(user=request.user, date=today).first()
        logger.info(f"Current user pick found: {current_user_pick is not None}")
        
        # Get user's recent picks (last 5)
        logger.info("Fetching user's recent picks")
        recent_picks = DailyPick.objects.filter(
            user=request.user
        ).select_related('player', 'winning_player').order_by('-date')[:5]
        logger.info(f"Found {len(recent_picks)} recent picks")
        
        # Get user stats
        logger.info("Calculating user stats")
        user_stats = get_user_stats(request.user)
        total_picks = user_stats.get('total_picks', 0)
        total_wins = user_stats.get('total_wins', 0)
        win_rate = user_stats.get('win_percentage', 0)
        logger.info(f"User stats: {total_picks} picks, {total_wins} wins, {win_rate}% win rate")
        
        # Get leaderboard
        logger.info("Generating leaderboard")
        users_with_picks = User.objects.filter(dailypick__isnull=False).distinct()
        logger.info(f"Found {users_with_picks.count()} users with picks")
        
        leaderboard = []
        
        for user in users_with_picks:
            stats = get_user_stats(user)
            if stats['total_picks'] > 0:
                leaderboard.append({
                    'username': user.username,
                    'total_picks': stats['total_picks'],
                    'total_wins': stats['total_wins'],
                    'win_percentage': stats['win_percentage']
                })
        
        # Sort leaderboard by win percentage (descending)
        leaderboard.sort(key=lambda x: (x['win_percentage'], x['total_wins']), reverse=True)
        logger.info(f"Leaderboard generated with {len(leaderboard)} entries")
        
        context = {
            'today_picks': today_picks,
            'current_user_pick': current_user_pick,
            'recent_picks': recent_picks,
            'total_picks': total_picks,
            'total_wins': total_wins,
            'win_rate': win_rate,
            'leaderboard': leaderboard,
            'debug_mode': settings.DEBUG
        }
        
        logger.info("Rendering dashboard template")
        return render(request, 'picks/dashboard.html', context)
        
    except (OperationalError, DatabaseError) as e:
        # Database connection error
        logger.error(f"Database connection error in dashboard view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        logger.error(f"Database settings: ENGINE={connection.settings_dict.get('ENGINE')}, NAME={connection.settings_dict.get('NAME')}")
        
        messages.error(request, "Unable to connect to the database. Please try again later.")
        
        # Return minimal context with error flag
        return render(request, 'picks/dashboard.html', {
            'today_picks': [],
            'current_user_pick': None,
            'recent_picks': [],
            'total_picks': 0,
            'total_wins': 0,
            'win_rate': 0,
            'leaderboard': [],
            'database_error': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })
        
    except Exception as e:
        # Other unexpected errors
        logger.error(f"Unexpected error in dashboard view: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        messages.error(request, "An error occurred while loading the dashboard. Please try again later.")
        
        # Return minimal context with error flag
        return render(request, 'picks/dashboard.html', {
            'today_picks': [],
            'current_user_pick': None,
            'recent_picks': [],
            'total_picks': 0,
            'total_wins': 0,
            'win_rate': 0,
            'leaderboard': [],
            'error_occurred': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })

@login_required
def make_pick(request):
    est_now = get_est_time()
    today = est_now.date()
    
    # Check if user already made a pick today
    existing_pick = DailyPick.objects.filter(user=request.user, date=today).first()
    if existing_pick:
        messages.warning(request, 'You have already made your pick for today.')
        return redirect('dashboard')
    
    
    if request.method == 'POST':
        try:
            # Get all players already picked today
            picked_players = DailyPick.objects.filter(date=today).values_list('player_id', flat=True)
            
            use_custom_player = request.POST.get('use_custom_player') == 'on'
            
            if use_custom_player:
                custom_player_name = clean_player_name(request.POST.get('custom_player_name', ''))
                if custom_player_name:
                    try:
                        validate_unique_player(custom_player_name, today)
                        player = Player.objects.create(
                            name=custom_player_name,
                            team='Custom',
                            position='N/A',
                            is_custom=True,
                            is_active=True
                        )
                    except ValidationError as e:
                        messages.error(request, str(e))
                        return redirect('make-pick')
                else:
                    messages.error(request, 'Please enter a player name.')
                    return redirect('make-pick')
            else:
                player_id = request.POST.get('player')
                if not player_id:
                    messages.error(request, 'Please select a player.')
                    return redirect('make-pick')
                
                if int(player_id) in picked_players:
                    player = Player.objects.get(id=player_id)
                    messages.error(request, f'{player.name} has already been picked today.')
                    return redirect('make-pick')
                
                player = Player.objects.get(id=player_id)
            
            pick = DailyPick.objects.create(
                user=request.user,
                date=today,
                player=player
            )
            
            # Create audit log entry
            PickAuditLog.objects.create(
                pick=pick,
                modified_by=request.user,
                action='create',
                new_value={'player': player.name, 'date': today.isoformat()}
            )
            
            messages.success(request, f'Pick submitted successfully: {player.name}')
            return redirect('dashboard')
            
        except IntegrityError:
            messages.error(request, "There was an error saving your pick. Please try again.")
            return redirect('make-pick')
    
    # Get all players already picked today for the form
    picked_players = DailyPick.objects.filter(date=today).values_list('player_id', flat=True)
    available_players = Player.objects.filter(is_custom=False, is_active=True).exclude(id__in=picked_players).order_by('name')
    
    context = {
        'available_players': available_players,
    }
    return render(request, 'picks/make_pick.html', context)

@staff_member_required
def admin_controls(request):
    """Admin control panel for managing picks and winners."""
    import logging
    import traceback
    from django.db import connection, OperationalError, DatabaseError
    
    logger = logging.getLogger(__name__)
    logger.info(f"Starting admin_controls view for user: {request.user.username}")
    
    try:
        # Test database connection first
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        
        # Get current date
        est_now = get_est_time()
        today = est_now.date()
        
        # Process POST requests
        if request.method == 'POST':
            action = request.POST.get('action')
            logger.info(f"Processing admin action: {action}")
            
            if action == 'select_winner':
                winner_date_str = request.POST.get('winner_date')
                if winner_date_str:
                    try:
                        winner_date = datetime.strptime(winner_date_str, '%Y-%m-%d').date()
                        
                        # Check if removing winner
                        if request.POST.get('remove_winner') == 'on':
                            logger.info(f"Removing winner for date: {winner_date}")
                            picks = DailyPick.objects.filter(date=winner_date)
                            for pick in picks:
                                pick.winning_player = None
                                pick.is_winner = False
                                pick.modified_by = request.user
                                pick.save()
                            messages.success(request, f'Removed winner for {winner_date}')
                        else:
                            # Set winner
                            use_custom_winner = request.POST.get('use_custom_winner') == 'on'
                            
                            if use_custom_winner:
                                custom_winner_name = clean_player_name(request.POST.get('custom_winner_name', ''))
                                if not custom_winner_name:
                                    messages.error(request, 'Please enter a custom winner name')
                                    return redirect('admin-controls')
                                
                                logger.info(f"Setting custom winner: {custom_winner_name} for date: {winner_date}")
                                winning_player, created = Player.objects.get_or_create(
                                    name=custom_winner_name,
                                    defaults={
                                        'team': 'Custom',
                                        'position': 'N/A',
                                        'is_custom': True,
                                        'is_active': True
                                    }
                                )
                            else:
                                winning_player_id = request.POST.get('winning_player')
                                if not winning_player_id:
                                    messages.error(request, 'Please select a winning player')
                                    return redirect('admin-controls')
                                
                                # Handle "No Winner" option
                                if winning_player_id == 'no_winner':
                                    logger.info(f"Setting 'No Winner' for date: {winner_date}")
                                    picks = DailyPick.objects.filter(date=winner_date)
                                    for pick in picks:
                                        # Create a special "No Winner" player if it doesn't exist
                                        no_winner_player, created = Player.objects.get_or_create(
                                            name="No Winner",
                                            defaults={
                                                'team': 'System',
                                                'position': 'N/A',
                                                'is_custom': True,
                                                'is_active': True
                                            }
                                        )
                                        pick.winning_player = no_winner_player
                                        pick.is_winner = False  # No one wins when there's no winner
                                        pick.modified_by = request.user
                                        pick.save()
                                    
                                    messages.success(request, f'Set "No Winner" for {winner_date}')
                                    return redirect('admin-controls')
                                
                                winning_player = Player.objects.get(id=winning_player_id)
                                logger.info(f"Setting winner: {winning_player.name} for date: {winner_date}")
                            
                            # Update all picks for this date
                            picks = DailyPick.objects.filter(date=winner_date)
                            for pick in picks:
                                pick.winning_player = winning_player
                                if pick.player.is_custom or winning_player.is_custom:
                                    pick.is_winner = (pick.player.name.lower().strip() == winning_player.name.lower().strip())
                                else:
                                    pick.is_winner = (pick.player == winning_player)
                                pick.modified_by = request.user
                                pick.save()
                            
                            messages.success(request, f'Set winner to {winning_player.name} for {winner_date}')
                    except ValueError:
                        messages.error(request, 'Invalid date format')
                else:
                    messages.error(request, 'Please select a date')
            
            elif action == 'remove_pick':
                pick_id = request.POST.get('pick_id')
                if pick_id:
                    try:
                        pick = DailyPick.objects.get(id=pick_id)
                        logger.info(f"Removing pick: {pick.id} for user: {pick.user.username}")
                        pick.delete()
                        messages.success(request, f'Removed pick for {pick.user.username}')
                    except DailyPick.DoesNotExist:
                        messages.error(request, 'Pick not found')
                else:
                    messages.error(request, 'No pick specified')
            
            elif action == 'run_migrations':
                logger.info("Running database migrations")
                try:
                    call_command('migrate')
                    messages.success(request, 'Migrations completed successfully')
                except Exception as e:
                    logger.error(f"Error running migrations: {str(e)}")
                    messages.error(request, f'Error running migrations: {str(e)}')
            
            elif action == 'populate_players':
                logger.info("Populating players from MLB.com")
                return populate_players(request)
            
            elif action == 'scrape_game_data':
                logger.info("Scraping game data from Baseball Reference")
                return scrape_game_data(request)
        
        # Get Orioles players for the form
        orioles_players = Player.objects.filter(is_custom=False, is_active=True).order_by('name')
        
        # Get all players (including inactive) for the roster display
        all_players = Player.objects.filter(is_custom=False).order_by('-is_active', 'name')
        
        # Get recent picks for display (last 20)
        recent_picks = DailyPick.objects.all().select_related(
            'user', 'player', 'winning_player'
        ).order_by('-date', '-created_at')[:20]
        
        context = {
            'today': today,
            'orioles_players': orioles_players,
            'all_players': all_players,
            'recent_picks': recent_picks,
            'debug_mode': settings.DEBUG
        }
        
        logger.info("Rendering admin_controls template")
        return render(request, 'picks/admin_controls.html', context)
        
    except (OperationalError, DatabaseError) as e:
        # Database connection error
        logger.error(f"Database connection error in admin_controls view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        messages.error(request, "Unable to connect to the database. Please try again later.")
        
        # Return minimal context with error flag
        return render(request, 'picks/admin_controls.html', {
            'today': date.today(),
            'orioles_players': [],
            'all_players': [],
            'recent_picks': [],
            'database_error': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })
        
    except Exception as e:
        # Other unexpected errors
        logger.error(f"Unexpected error in admin_controls view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        messages.error(request, "An error occurred while loading the admin controls. Please try again later.")
        
        # Return minimal context with error flag
        return render(request, 'picks/admin_controls.html', {
            'today': date.today(),
            'orioles_players': [],
            'all_players': [],
            'recent_picks': [],
            'error_occurred': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })

@login_required
def day_detail(request, year, month, day):
    try:
        selected_date = date(year, month, day)
        est_now = get_est_time()
        
        # Only allow POST requests (edits) from staff members
        if request.method == 'POST' and request.user.is_staff:
            action = request.POST.get('action')
            
            if action == 'update_pick':
                pick_id = request.POST.get('pick_id')
                pick = DailyPick.objects.get(id=pick_id)
                old_player = pick.player
                
                custom_player_name = request.POST.get('custom_player_name', '').strip()
                if custom_player_name:
                    player, created = Player.objects.get_or_create(
                        name=custom_player_name,
                        defaults={
                            'team': 'Custom',
                            'position': 'N/A',
                            'is_custom': True
                        }
                    )
                else:
                    new_player_id = request.POST.get('new_player')
                    player = Player.objects.get(id=new_player_id)
                
                pick.player = player
                pick.modified_by = request.user
                pick.save()
                
                # Create audit log entry
                PickAuditLog.objects.create(
                    pick=pick,
                    modified_by=request.user,
                    action='update',
                    old_value={'player': old_player.name},
                    new_value={'player': player.name}
                )
                
                messages.success(request, f'Updated {pick.user.username}\'s pick to {player.name}')
                
            elif action == 'delete_pick':
                pick_id = request.POST.get('pick_id')
                pick = DailyPick.objects.get(id=pick_id)
                user_name = pick.user.username
                player_name = pick.player.name
                
                # Create audit log entry before deletion
                PickAuditLog.objects.create(
                    pick=pick,
                    modified_by=request.user,
                    action='delete',
                    old_value={'player': player_name, 'user': user_name}
                )
                
                pick.delete()
                messages.success(request, f'Deleted pick for {user_name}')
                
            elif action == 'update_winner':
                use_custom_winner = request.POST.get('use_custom_winner') == 'on'
                
                if use_custom_winner:
                    custom_winner_name = clean_player_name(request.POST.get('custom_winner_name', ''))
                    if custom_winner_name:
                        winning_player, created = Player.objects.get_or_create(
                            name=custom_winner_name,
                            defaults={
                                'team': 'Custom',
                                'position': 'N/A',
                                'is_custom': True
                            }
                        )
                    else:
                        messages.error(request, 'Please enter a custom winner name')
                        return redirect('day_detail', year=year, month=month, day=day)
                else:
                    winning_player_id = request.POST.get('winning_player')
                    if winning_player_id:
                        winning_player = Player.objects.get(id=winning_player_id)
                    else:
                        messages.error(request, 'Please select a winning player')
                        return redirect('day_detail', year=year, month=month, day=day)
                
                # Update all picks for this date
                picks = DailyPick.objects.filter(date=selected_date)
                for pick in picks:
                    old_winner = pick.winning_player
                    pick.winning_player = winning_player
                    if pick.player.is_custom or winning_player.is_custom:
                        pick.is_winner = (pick.player.name.lower().strip() == winning_player.name.lower().strip())
                    else:
                        pick.is_winner = (pick.player == winning_player)
                    pick.modified_by = request.user
                    pick.save()
                    
                    # Create audit log entry
                    PickAuditLog.objects.create(
                        pick=pick,
                        modified_by=request.user,
                        action='update_winner',
                        old_value={'winning_player': old_winner.name if old_winner else None},
                        new_value={'winning_player': winning_player.name}
                    )
                
                messages.success(request, f'Updated winning player to {winning_player.name}')
            
            elif action == 'remove_winner':
                picks = DailyPick.objects.filter(date=selected_date)
                for pick in picks:
                    old_winner = pick.winning_player
                    pick.winning_player = None
                    pick.is_winner = False
                    pick.modified_by = request.user
                    pick.save()
                    
                    # Create audit log entry
                    PickAuditLog.objects.create(
                        pick=pick,
                        modified_by=request.user,
                        action='remove_winner',
                        old_value={'winning_player': old_winner.name if old_winner else None},
                        new_value={'winning_player': None}
                    )
                
                messages.success(request, 'Removed winning player')
        elif request.method == 'POST' and not request.user.is_staff:
            messages.error(request, 'You do not have permission to edit picks or winners')
            return redirect('day_detail', year=year, month=month, day=day)

        # Get all picks for this date
        picks = DailyPick.objects.filter(date=selected_date).select_related(
            'user', 'player', 'winning_player', 'modified_by'
        ).order_by('user__username')
        
        # Get all available players
        all_players = Player.objects.filter(is_custom=False, is_active=True).order_by('name')
        
        context = {
            'date': selected_date,
            'picks': picks,
            'all_players': all_players,
            'winning_player': picks.first().winning_player if picks.exists() else None,
            'is_past_cutoff': est_now > timezone.datetime.combine(
                selected_date, 
                timezone.datetime.strptime("19:05", "%H:%M").time()
            ).replace(tzinfo=timezone.get_current_timezone())
        }
        return render(request, 'picks/day_detail.html', context)
        
    except (ValueError, Player.DoesNotExist, DailyPick.DoesNotExist) as e:
        messages.error(request, str(e))
        return redirect('history')

def export_history(request):
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="pick2click_history.csv"'},
    )
    
    writer = csv.writer(response)
    writer.writerow(['Date', 'User', 'Player Picked', 'Winning Player', 'Result', 'Pick Time (EST)', 'Last Modified', 'Modified By'])
    
    picks = DailyPick.objects.all().select_related(
        'user', 'player', 'winning_player', 'modified_by'
    ).order_by('-date', 'user__username')
    
    for pick in picks:
        writer.writerow([
            pick.date.strftime('%Y-%m-%d'),
            pick.user.username,
            pick.player.name,
            pick.winning_player.name if pick.winning_player else 'Not Set',
            'Win' if pick.is_winner else 'Loss' if pick.winning_player else 'Pending',
            pick.created_at.astimezone(timezone.get_current_timezone()).strftime('%Y-%m-%d %I:%M %p EST'),
            pick.last_modified.astimezone(timezone.get_current_timezone()).strftime('%Y-%m-%d %I:%M %p EST'),
            pick.modified_by.username if pick.modified_by else 'N/A'
        ])
    
    return response

@login_required
def history(request):
    """History view showing calendar of picks and player statistics."""
    import logging
    import traceback
    from django.db import connection, OperationalError, DatabaseError
    from .models import GameData
    
    logger = logging.getLogger(__name__)
    logger.info(f"Starting history view for user: {request.user.username}")
    
    try:
        # Test database connection first
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        
        # Get current date and requested month/year
        today = date.today()
        
        # Fix URL parameter parsing
        year_param = request.GET.get('year')
        month_param = request.GET.get('month')
        
        # Log the raw parameters for debugging
        logger.info(f"Raw URL parameters - year: {year_param}, month: {month_param}")
        
        # Parse year parameter, ensuring it's a valid integer
        try:
            year = int(year_param) if year_param else today.year
            # Validate year is reasonable (between 2020 and 2030)
            if year < 2020 or year > 2030:
                year = today.year
                logger.warning(f"Invalid year parameter: {year_param}, using current year: {today.year}")
        except (ValueError, TypeError):
            year = today.year
            logger.warning(f"Could not parse year parameter: {year_param}, using current year: {today.year}")
        
        # Parse month parameter, ensuring it's a valid integer between 1-12
        try:
            month = int(month_param) if month_param else today.month
            if month < 1 or month > 12:
                month = today.month
                logger.warning(f"Invalid month parameter: {month_param}, using current month: {today.month}")
        except (ValueError, TypeError):
            month = today.month
            logger.warning(f"Could not parse month parameter: {month_param}, using current month: {today.month}")
        
        logger.info(f"Generating calendar for {year}-{month}")
        
        # Create calendar data
        cal = monthcalendar(year, month)
        
        # Get all picks for this month
        start_date = date(year, month, 1)
        if month == 12:
            end_date = date(year + 1, 1, 1) - timezone.timedelta(days=1)
        else:
            end_date = date(year, month + 1, 1) - timezone.timedelta(days=1)
        
        logger.info(f"Fetching picks from {start_date} to {end_date}")
        month_picks = DailyPick.objects.filter(
            date__gte=start_date, 
            date__lte=end_date
        ).select_related('user', 'player', 'winning_player')
        
        # Get game data for this month
        month_games = GameData.objects.filter(
            date__gte=start_date,
            date__lte=end_date
        )
        
        # Organize picks by day
        picks_by_day = {}
        for pick in month_picks:
            day = pick.date.day
            if day not in picks_by_day:
                picks_by_day[day] = []
            picks_by_day[day].append(pick)
            
        # Organize games by day
        games_by_day = {}
        for game in month_games:
            day = game.date.day
            games_by_day[day] = game
        
        # Format calendar weeks
        calendar_weeks = []
        for week in cal:
            formatted_week = []
            for day in week:
                if day != 0:
                    current_date = date(year, month, day)
                    is_today = current_date == today
                    day_picks = picks_by_day.get(day, [])
                    game_data = games_by_day.get(day, None)
                    
                    # Check if there's a winner for this day
                    winning_player = None
                    winning_users = []
                    has_winner = False
                    
                    if day_picks and day_picks[0].winning_player:
                        winning_player = day_picks[0].winning_player
                        has_winner = True
                        for pick in day_picks:
                            if pick.is_winner:
                                winning_users.append(pick.user.username)
                    
                    formatted_week.append({
                        'day': day,
                        'has_picks': bool(day_picks),
                        'is_today': is_today,
                        'winning_player': winning_player,
                        'winning_users': winning_users,
                        'has_winner': has_winner,
                        'total_picks': len(day_picks),
                        'game_data': game_data
                    })
                else:
                    formatted_week.append({
                        'day': 0,
                        'has_picks': False,
                        'is_today': False,
                        'winning_player': None,
                        'winning_users': [],
                        'has_winner': False,
                        'total_picks': 0,
                        'game_data': None
                    })
            calendar_weeks.append(formatted_week)
        
        # Calculate previous and next months
        if month == 1:
            prev_year = year - 1
            prev_month = 12
        else:
            prev_year = year
            prev_month = month - 1
            
        if month == 12:
            next_year = year + 1
            next_month = 1
        else:
            next_year = year
            next_month = month + 1
        
        # Create properly formatted URL parameters
        prev_month_url = f"?year={prev_year}&month={prev_month}"
        next_month_url = f"?year={next_year}&month={next_month}"
        
        # Get player statistics by user
        logger.info("Calculating player statistics by user")
        user_player_stats = {}
        
        # Get all users who have made picks
        users_with_picks = User.objects.filter(dailypick__isnull=False).distinct()
        
        for user in users_with_picks:
            user_picks = DailyPick.objects.filter(user=user).select_related('player')
            total_picks = user_picks.count()
            
            if total_picks == 0:
                continue
            
            # Calculate player statistics
            player_counts = {}
            player_wins = {}
            
            for pick in user_picks:
                player_name = pick.player.name
                if player_name not in player_counts:
                    player_counts[player_name] = 0
                    player_wins[player_name] = 0
                
                player_counts[player_name] += 1
                if pick.is_winner:
                    player_wins[player_name] += 1
            
            # Convert to list of dictionaries
            stats = []
            for player_name, times_chosen in player_counts.items():
                wins = player_wins.get(player_name, 0)
                
                # Safely calculate percentages
                pick_percentage = (times_chosen / total_picks) * 100 if total_picks > 0 else 0
                win_percentage = (wins / times_chosen) * 100 if times_chosen > 0 else 0
                
                stats.append({
                    'player_name': player_name,
                    'times_chosen': times_chosen,
                    'wins': wins,
                    'pick_percentage': f"{pick_percentage:.1f}%",
                    'win_percentage': f"{win_percentage:.1f}%"
                })
            
            # Sort by times chosen (descending)
            stats.sort(key=lambda x: x['times_chosen'], reverse=True)
            
            user_player_stats[user.username] = {
                'total_picks': total_picks,
                'stats': stats
            }
        
        context = {
            'calendar_weeks': calendar_weeks,
            'current_month': month,
            'current_month_name': date(year, month, 1).strftime('%B'),
            'current_year': year,
            'prev_month': prev_month_url,
            'next_month': next_month_url,
            'user_player_stats': user_player_stats,
            'debug_mode': settings.DEBUG
        }
        
        logger.info("Rendering history template")
        return render(request, 'picks/history.html', context)
        
    except (OperationalError, DatabaseError) as e:
        # Database connection error
        logger.error(f"Database connection error in history view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        messages.error(request, "Unable to connect to the database. Please try again later.")
        
        # Calculate minimal calendar data
        today = date.today()
        year = int(request.GET.get('year', today.year))
        month = int(request.GET.get('month', today.month))
        cal = monthcalendar(year, month)
        
        # Format calendar weeks with minimal data
        calendar_weeks = []
        for week in cal:
            formatted_week = []
            for day in week:
                if day != 0:
                    is_today = date(year, month, day) == today
                    formatted_week.append({
                        'day': day,
                        'has_picks': False,
                        'is_today': is_today,
                        'winning_player': None,
                        'winning_users': [],
                        'has_winner': False,
                        'total_picks': 0
                    })
                else:
                    formatted_week.append({
                        'day': 0,
                        'has_picks': False,
                        'is_today': False,
                        'winning_player': None,
                        'winning_users': [],
                        'has_winner': False,
                        'total_picks': 0
                    })
            calendar_weeks.append(formatted_week)
        
        # Calculate previous and next months
        if month == 1:
            prev_year = year - 1
            prev_month = 12
        else:
            prev_year = year
            prev_month = month - 1
            
        if month == 12:
            next_year = year + 1
            next_month = 1
        else:
            next_year = year
            next_month = month + 1
        
        # Create properly formatted URL parameters
        prev_month_url = f"?year={prev_year}&month={prev_month}"
        next_month_url = f"?year={next_year}&month={next_month}"
        
        # Return minimal context with error flag
        return render(request, 'picks/history.html', {
            'calendar_weeks': calendar_weeks,
            'current_month': month,
            'current_month_name': date(year, month, 1).strftime('%B'),
            'current_year': year,
            'prev_month': prev_month_url,
            'next_month': next_month_url,
            'user_player_stats': {},
            'database_error': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })
        
    except Exception as e:
        # Other unexpected errors
        logger.error(f"Unexpected error in history view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        messages.error(request, "An error occurred while loading the history page. Please try again later.")
        
        # Calculate minimal calendar data
        today = date.today()
        year = int(request.GET.get('year', today.year))
        month = int(request.GET.get('month', today.month))
        cal = monthcalendar(year, month)
        
        # Format calendar weeks with minimal data
        calendar_weeks = []
        for week in cal:
            formatted_week = []
            for day in week:
                if day != 0:
                    is_today = date(year, month, day) == today
                    formatted_week.append({
                        'day': day,
                        'has_picks': False,
                        'is_today': is_today,
                        'winning_player': None,
                        'winning_users': [],
                        'has_winner': False,
                        'total_picks': 0
                    })
                else:
                    formatted_week.append({
                        'day': 0,
                        'has_picks': False,
                        'is_today': False,
                        'winning_player': None,
                        'winning_users': [],
                        'has_winner': False,
                        'total_picks': 0
                    })
            calendar_weeks.append(formatted_week)
        
        # Calculate previous and next months
        if month == 1:
            prev_year = year - 1
            prev_month = 12
        else:
            prev_year = year
            prev_month = month - 1
            
        if month == 12:
            next_year = year + 1
            next_month = 1
        else:
            next_year = year
            next_month = month + 1
        
        # Create properly formatted URL parameters
        prev_month_url = f"?year={prev_year}&month={prev_month}"
        next_month_url = f"?year={next_year}&month={next_month}"
        
        # Return minimal context with error flag
        return render(request, 'picks/history.html', {
            'calendar_weeks': calendar_weeks,
            'current_month': month,
            'current_month_name': date(year, month, 1).strftime('%B'),
            'current_year': year,
            'prev_month': prev_month_url,
            'next_month': next_month_url,
            'user_player_stats': {},
            'error_occurred': True,
            'debug_mode': settings.DEBUG,
            'username': request.user.username
        })

def debug_player_stats(request):
    """Debug view to show raw player statistics data"""
    if not request.user.is_staff:
        messages.error(request, "You don't have permission to access this page.")
        return redirect('dashboard')
    
    # Get all users who have made picks
    users_with_picks = User.objects.filter(dailypick__isnull=False).distinct()
    
    # Initialize debug data
    debug_data = []
    
    # For each user, get their picks and stats
    for user in users_with_picks:
        user_picks = DailyPick.objects.filter(user=user).select_related('player')
        total_picks = user_picks.count()
        
        if total_picks == 0:
            continue
        
        # Get raw pick data
        pick_data = []
        for pick in user_picks:
            pick_data.append({
                'date': pick.date,
                'player': pick.player.name,
                'is_winner': pick.is_winner,
                'winning_player': pick.winning_player.name if pick.winning_player else None
            })
        
        # Simplified approach to calculate player statistics
        player_counts = {}
        player_wins = {}
        
        for pick in user_picks:
            player_name = pick.player.name
            if player_name not in player_counts:
                player_counts[player_name] = 0
                player_wins[player_name] = 0
            
            player_counts[player_name] += 1
            if pick.is_winner:
                player_wins[player_name] += 1
        
        # Convert to list of dictionaries
        stats = []
        for player_name, times_chosen in player_counts.items():
            wins = player_wins.get(player_name, 0)
            
            # Safely calculate percentages to avoid division by zero
            try:
                pick_percentage = (times_chosen / total_picks) * 100 if total_picks > 0 else 0
            except ZeroDivisionError:
                pick_percentage = 0
                
            try:
                win_percentage = (wins / times_chosen) * 100 if times_chosen > 0 else 0
            except ZeroDivisionError:
                win_percentage = 0
            
            stats.append({
                'player_name': player_name,
                'times_chosen': times_chosen,
                'wins': wins,
                'pick_percentage': f"{pick_percentage:.1f}%",
                'win_percentage': f"{win_percentage:.1f}%"
            })
        
        # Sort by times chosen (descending)
        stats.sort(key=lambda x: x['times_chosen'], reverse=True)
        
        debug_data.append({
            'username': user.username,
            'total_picks': total_picks,
            'picks': pick_data,
            'stats': stats
        })
    
    context = {
        'debug_data': debug_data
    }
    
    return render(request, 'picks/debug_player_stats.html', context)

@staff_member_required
def run_migrations(request):
    """
    Run database migrations - admin only
    """
    if request.method == 'POST':
        try:
            call_command('migrate')
            return HttpResponse('Migrations completed successfully')
        except Exception as e:
            return HttpResponse(f'Error running migrations: {str(e)}', status=500)
    return HttpResponse('Use POST method to run migrations')

@staff_member_required
def populate_players(request):
    """
    Populate the database with Orioles players - admin only
    """
    try:
        # Fetch the Orioles roster from MLB.com
        url = "https://www.mlb.com/orioles/roster"
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch roster: HTTP {response.status_code}")
        
        # Parse the HTML
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Initialize counters and player list
        added_count = 0
        skipped_count = 0
        orioles_players = []
        
        # Process pitchers
        pitcher_table = soup.find('table', {'class': 'roster__table'})
        if pitcher_table:
            for row in pitcher_table.find_all('tr')[1:]:  # Skip header row
                cells = row.find_all('td')
                if len(cells) >= 1:
                    name_cell = cells[0].find('a')
                    if name_cell:
                        name = name_cell.text.strip()
                        # Get B/T info to determine position
                        bt_info = cells[1].text.strip() if len(cells) > 1 else "R/R"
                        
                        # Determine if starter or reliever based on roster page structure
                        position = "SP"  # Default to starting pitcher
                        orioles_players.append({
                            'name': name,
                            'team': 'Baltimore Orioles',
                            'position': position
                        })
        
        # Process catchers
        catcher_table = soup.find_all('table', {'class': 'roster__table'})
        if len(catcher_table) > 1:
            for row in catcher_table[1].find_all('tr')[1:]:  # Skip header row
                cells = row.find_all('td')
                if len(cells) >= 1:
                    name_cell = cells[0].find('a')
                    if name_cell:
                        name = name_cell.text.strip()
                        orioles_players.append({
                            'name': name,
                            'team': 'Baltimore Orioles',
                            'position': 'C'
                        })
        
        # Process infielders
        infielder_table = soup.find_all('table', {'class': 'roster__table'})
        if len(infielder_table) > 2:
            for row in infielder_table[2].find_all('tr')[1:]:  # Skip header row
                cells = row.find_all('td')
                if len(cells) >= 1:
                    name_cell = cells[0].find('a')
                    if name_cell:
                        name = name_cell.text.strip()
                        orioles_players.append({
                            'name': name,
                            'team': 'Baltimore Orioles',
                            'position': 'IF'
                        })
        
        # Process outfielders
        outfielder_table = soup.find_all('table', {'class': 'roster__table'})
        if len(outfielder_table) > 3:
            for row in outfielder_table[3].find_all('tr')[1:]:  # Skip header row
                cells = row.find_all('td')
                if len(cells) >= 1:
                    name_cell = cells[0].find('a')
                    if name_cell:
                        name = name_cell.text.strip()
                        orioles_players.append({
                            'name': name,
                            'team': 'Baltimore Orioles',
                            'position': 'OF'
                        })
        
        # If we couldn't parse the tables properly, fall back to a more generic approach
        if not orioles_players:
            # Look for player names throughout the page
            player_links = soup.select('a[href^="/player/"]')
            for link in player_links:
                name = link.text.strip()
                if name and len(name) > 3:  # Basic validation to avoid empty or invalid names
                    orioles_players.append({
                        'name': name,
                        'team': 'Baltimore Orioles',
                        'position': 'Unknown'  # We can't determine position with this fallback
                    })
        
        # Add players to the database
        for player_data in orioles_players:
            player, created = Player.objects.get_or_create(
                name=player_data['name'],
                defaults={
                    'team': player_data['team'],
                    'position': player_data['position'],
                    'is_custom': False
                }
            )
            
            if created:
                added_count += 1
            else:
                skipped_count += 1
        
        if added_count > 0 or skipped_count > 0:
            messages.success(request, f'Successfully added {added_count} players from MLB.com. Skipped {skipped_count} existing players.')
        else:
            messages.warning(request, 'No players were found or added from the MLB website. Using backup player list.')
            
            # Fallback to a basic list of key Orioles players if web scraping fails
            backup_players = [
                {'name': 'Adley Rutschman', 'team': 'Baltimore Orioles', 'position': 'C'},
                {'name': 'Ryan Mountcastle', 'team': 'Baltimore Orioles', 'position': '1B'},
                {'name': 'Gunnar Henderson', 'team': 'Baltimore Orioles', 'position': 'SS/3B'},
                {'name': 'Cedric Mullins', 'team': 'Baltimore Orioles', 'position': 'CF'},
                {'name': 'Anthony Santander', 'team': 'Baltimore Orioles', 'position': 'RF'},
                {'name': 'Kyle Bradish', 'team': 'Baltimore Orioles', 'position': 'SP'},
                {'name': 'Corbin Burnes', 'team': 'Baltimore Orioles', 'position': 'SP'},
                {'name': 'Félix Bautista', 'team': 'Baltimore Orioles', 'position': 'RP'},
            ]
            
            backup_added = 0
            backup_skipped = 0
            
            for player_data in backup_players:
                player, created = Player.objects.get_or_create(
                    name=player_data['name'],
                    defaults={
                        'team': player_data['team'],
                        'position': player_data['position'],
                        'is_custom': False
                    }
                )
                
                if created:
                    backup_added += 1
                else:
                    backup_skipped += 1
            
            messages.success(request, f'Added {backup_added} players from backup list. Skipped {backup_skipped} existing players.')
            
    except Exception as e:
        messages.error(request, f'Error adding players: {str(e)}')
    
    return redirect('admin-controls')

def make_admin(request, username):
    """
    Make a user an admin (staff and superuser)
    This is a one-time use function that should be removed after use
    """
    # Simple security check - only allow this to be used once when there are no admins
    if User.objects.filter(is_staff=True).exists():
        return HttpResponse("This function is no longer available as admins already exist.", status=403)
    
    try:
        user = User.objects.get(username=username)
        user.is_staff = True
        user.is_superuser = True
        user.save()
        return HttpResponse(f"User {username} is now an admin (staff and superuser)!")
    except User.DoesNotExist:
        return HttpResponse(f"User {username} not found", status=404)

@csrf_exempt
def debug_info(request):
    """
    View to display debug information about the environment.
    Only accessible when DEBUG is True.
    """
    if not settings.DEBUG:
        return JsonResponse({"error": "Debug mode is not enabled"}, status=403)
    
    # Collect environment variables (excluding sensitive ones)
    env_vars = {}
    for key, value in os.environ.items():
        if not any(sensitive in key.lower() for sensitive in ['secret', 'password', 'token', 'key']):
            env_vars[key] = value
    
    # Collect database settings (excluding sensitive info)
    db_settings = {}
    for key, value in settings.DATABASES['default'].items():
        if key.lower() not in ['password', 'user']:
            db_settings[key] = str(value)
    
    # Collect other relevant settings
    debug_data = {
        "environment_variables": env_vars,
        "database_settings": db_settings,
        "debug_mode": settings.DEBUG,
        "allowed_hosts": settings.ALLOWED_HOSTS,
        "static_root": str(settings.STATIC_ROOT),
        "static_url": settings.STATIC_URL,
        "middleware": settings.MIDDLEWARE,
        "installed_apps": settings.INSTALLED_APPS,
        "python_version": os.sys.version,
    }
    
    return JsonResponse(debug_data)

@csrf_exempt
def test_database(request):
    """
    Simple view to test database connectivity.
    """
    import logging
    import traceback
    from django.db import connection, OperationalError, DatabaseError
    
    logger = logging.getLogger('picks')
    logger.info("Database test view called")
    
    try:
        # Test database connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
        
        # Test a simple query
        from django.contrib.auth.models import User
        user_count = User.objects.count()
        
        # Test a query from our app
        from .models import Player
        player_count = Player.objects.count()
        
        return JsonResponse({
            "status": "success",
            "message": "Database connection successful",
            "database_engine": connection.settings_dict.get('ENGINE', 'unknown'),
            "database_name": connection.settings_dict.get('NAME', 'unknown'),
            "test_query_result": result[0] if result else None,
            "user_count": user_count,
            "player_count": player_count
        })
        
    except (OperationalError, DatabaseError) as e:
        # Log database errors
        logger.error(f"Database connection error in test view: {str(e)}")
        logger.error(f"Database settings: ENGINE={connection.settings_dict.get('ENGINE')}, NAME={connection.settings_dict.get('NAME')}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            "status": "error",
            "error_type": "database_error",
            "message": str(e),
            "database_engine": connection.settings_dict.get('ENGINE', 'unknown'),
            "database_name": connection.settings_dict.get('NAME', 'unknown')
        }, status=500)
        
    except Exception as e:
        # Log other errors
        logger.error(f"Unexpected error in database test view: {str(e)}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            "status": "error",
            "error_type": "unexpected_error",
            "message": str(e)
        }, status=500)

@csrf_exempt
def health_check(request):
    """
    Simple health check endpoint for Render to verify the application is running.
    """
    from django.http import HttpResponse
    return HttpResponse("OK", content_type="text/plain")

@csrf_exempt
def debug_dashboard(request):
    """
    Debug view to help diagnose dashboard issues.
    """
    import logging
    import traceback
    from django.db import connection, OperationalError, DatabaseError
    
    logger = logging.getLogger('picks')
    logger.info("Debug dashboard view called")
    
    try:
        # Test database connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
        
        # Test basic queries
        from django.contrib.auth.models import User
        user_count = User.objects.count()
        
        # Test picks app queries
        from .models import Player, DailyPick
        player_count = Player.objects.count()
        pick_count = DailyPick.objects.count()
        
        # Get current date
        from django.utils import timezone
        from .utils import get_est_time
        est_now = get_est_time()
        today = est_now.date()
        
        # Try to run the specific queries that might be failing in the dashboard
        today_picks = DailyPick.objects.filter(date=today).select_related('user', 'player').count()
        
        # Check if the user is authenticated and try user-specific queries
        user_specific_data = {}
        if request.user.is_authenticated:
            user_pick = DailyPick.objects.filter(user=request.user, date=today).exists()
            recent_picks = DailyPick.objects.filter(user=request.user).count()
            user_specific_data = {
                'username': request.user.username,
                'has_pick_today': user_pick,
                'recent_picks_count': recent_picks
            }
        
        # Check environment variables
        import os
        env_debug = os.environ.get('DJANGO_DEBUG', 'Not Set')
        
        return JsonResponse({
            "status": "success",
            "message": "Debug dashboard check successful",
            "database_connection": "OK",
            "database_engine": connection.settings_dict.get('ENGINE', 'unknown'),
            "database_name": connection.settings_dict.get('NAME', 'unknown'),
            "test_query_result": result[0] if result else None,
            "user_count": user_count,
            "player_count": player_count,
            "pick_count": pick_count,
            "today_picks_count": today_picks,
            "user_specific_data": user_specific_data,
            "settings_debug": settings.DEBUG,
            "env_debug": env_debug,
            "today": str(today)
        })
        
    except (OperationalError, DatabaseError) as e:
        # Log database errors
        logger.error(f"Database connection error in debug dashboard: {str(e)}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            "status": "error",
            "error_type": "database_error",
            "message": str(e),
            "database_engine": connection.settings_dict.get('ENGINE', 'unknown'),
            "database_name": connection.settings_dict.get('NAME', 'unknown')
        }, status=500)
        
    except Exception as e:
        # Log other errors
        logger.error(f"Unexpected error in debug dashboard: {str(e)}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            "status": "error",
            "error_type": "unexpected_error",
            "message": str(e),
            "traceback": traceback.format_exc()
        }, status=500)

@staff_member_required
def scrape_game_data(request):
    """Scrape game data from Baseball Reference and store it in the database."""
    import logging
    import traceback
    import requests
    from bs4 import BeautifulSoup
    from datetime import datetime
    from .models import GameData, DailyPick, Player, PickAuditLog
    import re
    import time
    import random
    
    logger = logging.getLogger(__name__)
    logger.info(f"Starting scrape_game_data view for user: {request.user.username}")
    
    try:
        # Define headers to mimic a real browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0',
        }
        
        # Fetch the Baseball Reference page with retry logic
        url = "https://www.baseball-reference.com/teams/BAL/2024-schedule-scores.shtml"
        
        # Retry parameters
        max_retries = 5
        retry_delay = 2  # Initial delay in seconds
        
        # Retry loop
        for retry in range(max_retries):
            try:
                logger.info(f"Attempting to fetch Baseball Reference page (attempt {retry+1}/{max_retries})")
                response = requests.get(url, headers=headers)
                response.raise_for_status()
                break  # If successful, break out of the retry loop
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429:  # Too Many Requests
                    if retry < max_retries - 1:  # If not the last retry
                        # Calculate exponential backoff with jitter
                        sleep_time = retry_delay * (2 ** retry) + random.uniform(0, 1)
                        logger.warning(f"Rate limited (429). Retrying in {sleep_time:.2f} seconds...")
                        time.sleep(sleep_time)
                        continue
                # If we've exhausted retries or it's another error, re-raise
                raise
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find the schedule table
        schedule_table = soup.find('table', {'id': 'team_schedule'})
        if not schedule_table:
            messages.error(request, "Could not find schedule table on Baseball Reference page.")
            return redirect('admin-controls')
        
        # Process each row in the table
        rows = schedule_table.find('tbody').find_all('tr')
        games_added = 0
        games_updated = 0
        winners_set = 0
        
        for row in rows:
            # Skip header rows or rows without game data
            if 'class' in row.attrs and ('thead' in row.attrs['class'] or 'spacer' in row.attrs['class']):
                continue
                
            # Extract date
            date_cell = row.find('td', {'data-stat': 'date_game'})
            if not date_cell or not date_cell.text.strip():
                continue
                
            # Parse date (format: "Monday, Apr 1")
            date_str = date_cell.text.strip()
            try:
                # Log the raw date string for debugging
                logger.info(f"Parsing date string: {date_str}")
                
                # Handle different date formats
                if ',' in date_str:
                    # Format: "Monday, Apr 1" or "Monday, Sep 1"
                    day_of_week, date_part = date_str.split(',', 1)
                    date_part = date_part.strip()
                    
                    # Try to parse with different formats
                    try:
                        # First try with standard format
                        date_obj = datetime.strptime(date_part + ", 2024", "%b %d, %Y")
                    except ValueError:
                        # If that fails, try with full month name
                        try:
                            date_obj = datetime.strptime(date_part + ", 2024", "%B %d, %Y")
                        except ValueError:
                            # If that fails too, try with just the day number
                            try:
                                month_str, day_str = date_part.split()
                                month_map = {
                                    'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
                                    'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12,
                                    'January': 1, 'February': 2, 'March': 3, 'April': 4, 'May': 5, 'June': 6,
                                    'July': 7, 'August': 8, 'September': 9, 'October': 10, 'November': 11, 'December': 12
                                }
                                month_num = month_map.get(month_str, None)
                                if month_num and day_str.isdigit():
                                    date_obj = datetime(2024, month_num, int(day_str))
                                else:
                                    raise ValueError(f"Could not parse month: {month_str}")
                            except Exception as e:
                                logger.error(f"Failed to parse date with custom logic: {date_part}, error: {str(e)}")
                                raise
                else:
                    # Try to handle other formats
                    logger.warning(f"Unexpected date format: {date_str}, attempting to parse")
                    date_obj = datetime.strptime(date_str + ", 2024", "%B %d, %Y")
                
                game_date = date_obj.date()
                logger.info(f"Successfully parsed date: {date_str} -> {game_date}")
                
            except ValueError as e:
                logger.warning(f"Could not parse date: {date_str}, error: {str(e)}")
                continue
            
            # Extract opponent
            opponent_cell = row.find('td', {'data-stat': 'opp_ID'})
            if not opponent_cell:
                continue
            opponent = opponent_cell.text.strip()
            
            # Extract location (home/away)
            location_cell = row.find('td', {'data-stat': 'homestand'})
            location = "Home" if location_cell and location_cell.text.strip() == "" else "Away"
            
            # Extract scores
            orioles_score_cell = row.find('td', {'data-stat': 'R'})
            opponent_score_cell = row.find('td', {'data-stat': 'RA'})
            
            # Only process games that have been played
            if not orioles_score_cell or not orioles_score_cell.text.strip() or not opponent_score_cell or not opponent_score_cell.text.strip():
                continue
                
            orioles_score = int(orioles_score_cell.text.strip())
            opponent_score = int(opponent_score_cell.text.strip())
            is_win = orioles_score > opponent_score
            
            # Extract boxscore link for later use if this is a win
            boxscore_link = None
            if is_win:
                boxscore_cell = row.find('td', {'data-stat': 'boxscore'})
                if boxscore_cell and boxscore_cell.find('a'):
                    boxscore_link = boxscore_cell.find('a')['href']
                    if not boxscore_link.startswith('http'):
                        boxscore_link = f"https://www.baseball-reference.com{boxscore_link}"
            
            # Save to database
            game_data, created = GameData.objects.update_or_create(
                date=game_date,
                defaults={
                    'opponent': opponent,
                    'location': location,
                    'orioles_score': orioles_score,
                    'opponent_score': opponent_score,
                    'is_win': is_win
                }
            )
            
            if created:
                games_added += 1
            else:
                games_updated += 1
            
            # If this is a win and we have a boxscore link, check if we need to set a winner
            if is_win and boxscore_link:
                # Check if there are any picks for this date
                picks = DailyPick.objects.filter(date=game_date)
                
                # Check if we need to set a winner (either for existing picks or create a system pick)
                need_to_set_winner = picks.exists() and picks.first().winning_player is None
                
                # If no picks exist for this date but it's a win, we'll create a system pick
                create_system_pick = not picks.exists()
                
                if need_to_set_winner or create_system_pick:
                    logger.info(f"Found Orioles win on {game_date} without a winner set. Scraping boxscore.")
                    
                    try:
                        # Add a delay to avoid rate limiting (3-7 seconds)
                        sleep_time = 3 + random.uniform(0, 4)
                        logger.info(f"Waiting {sleep_time:.2f} seconds before fetching boxscore...")
                        time.sleep(sleep_time)
                        
                        # Fetch the boxscore page with retry logic
                        boxscore_fetched = False
                        for retry in range(max_retries):
                            try:
                                logger.info(f"Attempting to fetch boxscore page (attempt {retry+1}/{max_retries})")
                                boxscore_response = requests.get(boxscore_link, headers=headers)
                                boxscore_response.raise_for_status()
                                boxscore_fetched = True
                                break  # If successful, break out of the retry loop
                            except requests.exceptions.HTTPError as e:
                                if e.response.status_code == 429:  # Too Many Requests
                                    if retry < max_retries - 1:  # If not the last retry
                                        # Calculate exponential backoff with jitter
                                        sleep_time = retry_delay * (2 ** retry) + random.uniform(0, 1)
                                        logger.warning(f"Rate limited (429) on boxscore. Retrying in {sleep_time:.2f} seconds...")
                                        time.sleep(sleep_time)
                                        continue
                                # If we've exhausted retries or it's another error, log and continue with next game
                                logger.error(f"Failed to fetch boxscore after {max_retries} attempts: {str(e)}")
                                break
                        
                        if not boxscore_fetched:
                            logger.warning(f"Skipping boxscore processing for {game_date} due to fetch failure")
                            continue
                        
                        boxscore_soup = BeautifulSoup(boxscore_response.text, 'html.parser')
                        
                        # Find the WPA table for Orioles batters
                        wpa_table = None
                        tables = boxscore_soup.find_all('table')
                        for table in tables:
                            if table.get('id') and 'batting_wpa' in table.get('id') and 'BAL' in table.get('id'):
                                wpa_table = table
                                break
                        
                        if wpa_table:
                            # Find the player with the highest WPA
                            highest_wpa = -1
                            highest_wpa_player = None
                            
                            rows = wpa_table.find('tbody').find_all('tr')
                            for row in rows:
                                # Skip header rows
                                if 'class' in row.attrs and 'thead' in row.attrs['class']:
                                    continue
                                
                                # Get player name
                                name_cell = row.find('th', {'data-stat': 'player'})
                                if not name_cell or not name_cell.text.strip():
                                    continue
                                
                                player_name = name_cell.text.strip()
                                
                                # Get WPA value
                                wpa_cell = row.find('td', {'data-stat': 'wpa_bat'})
                                if not wpa_cell or not wpa_cell.text.strip():
                                    continue
                                
                                try:
                                    wpa = float(wpa_cell.text.strip())
                                    
                                    # Update highest WPA if this is higher
                                    if wpa > highest_wpa:
                                        highest_wpa = wpa
                                        highest_wpa_player = player_name
                                except ValueError:
                                    continue
                            
                            if highest_wpa_player:
                                logger.info(f"Found player with highest WPA: {highest_wpa_player} ({highest_wpa}) for game on {game_date}")
                                
                                # Clean up player name (remove any position indicators)
                                highest_wpa_player = re.sub(r'\s+\w+$', '', highest_wpa_player)
                                
                                # Try to find this player in our database
                                try:
                                    # First try exact match
                                    player = Player.objects.get(name=highest_wpa_player)
                                except Player.DoesNotExist:
                                    # Try case-insensitive match
                                    players = Player.objects.filter(name__iexact=highest_wpa_player)
                                    if players.exists():
                                        player = players.first()
                                    else:
                                        # Try partial match (e.g., "Anthony Santander" vs "A. Santander")
                                        last_name = highest_wpa_player.split()[-1]
                                        players = Player.objects.filter(name__icontains=last_name)
                                        if players.exists():
                                            player = players.first()
                                        else:
                                            # Create a custom player if we can't find a match
                                            player, created = Player.objects.get_or_create(
                                                name=highest_wpa_player,
                                                defaults={
                                                    'team': 'Baltimore Orioles',
                                                    'position': 'BAT',
                                                    'is_custom': True,
                                                    'is_active': True
                                                }
                                            )
                                
                                if need_to_set_winner:
                                    # Set this player as the winner for all existing picks on this date
                                    for pick in picks:
                                        pick.winning_player = player
                                        pick.is_winner = (pick.player == player)
                                        pick.modified_by = request.user
                                        pick.save()
                                
                                if create_system_pick:
                                    # Create a system user if it doesn't exist
                                    system_user, created = User.objects.get_or_create(
                                        username="system",
                                        defaults={
                                            'is_active': True,
                                            'is_staff': False
                                        }
                                    )
                                    
                                    # Create a system pick with the winning player as both the pick and winner
                                    system_pick = DailyPick.objects.create(
                                        user=system_user,
                                        date=game_date,
                                        player=player,
                                        winning_player=player,
                                        is_winner=True,
                                        modified_by=request.user
                                    )
                                    
                                    # Create audit log entry
                                    PickAuditLog.objects.create(
                                        pick=system_pick,
                                        modified_by=request.user,
                                        action='create_system_pick',
                                        new_value={
                                            'player': player.name,
                                            'date': game_date.isoformat(),
                                            'winning_player': player.name,
                                            'wpa_value': highest_wpa
                                        }
                                    )
                                
                                winners_set += 1
                                logger.info(f"Set {highest_wpa_player} as winner for {game_date}")
                        else:
                            logger.warning(f"Could not find WPA table for Orioles batters in boxscore for {game_date}")
                    
                    except Exception as e:
                        logger.error(f"Error processing boxscore for {game_date}: {str(e)}")
                        logger.error(f"Boxscore URL: {boxscore_link}")
                        # Continue with other games even if this one fails
        
        success_message = f"Successfully imported game data: {games_added} new games, {games_updated} updated games."
        if winners_set > 0:
            success_message += f" Automatically set winners for {winners_set} games."
        
        messages.success(request, success_message)
        return redirect('admin-controls')
        
    except requests.RequestException as e:
        logger.error(f"Error fetching Baseball Reference page: {str(e)}")
        messages.error(request, f"Error fetching Baseball Reference page: {str(e)}")
        return redirect('admin-controls')
        
    except Exception as e:
        logger.error(f"Unexpected error in scrape_game_data view: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        messages.error(request, f"An error occurred: {str(e)}")
        return redirect('admin-controls')