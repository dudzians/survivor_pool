from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('picks', '0005_pickauditlog'),
    ]

    operations = [
        migrations.AddField(
            model_name='player',
            name='is_active',
            field=models.BooleanField(default=True),
        ),
    ]
