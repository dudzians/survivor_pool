from django.utils import timezone
from zoneinfo import ZoneInfo
from django.core.exceptions import ValidationError
from django.core.cache import cache
from django.db import OperationalError, DatabaseError
import traceback
import logging
from .models import Player

logger = logging.getLogger(__name__)

def get_est_time():
    """Return the current time in Eastern Time Zone."""
    return timezone.now().astimezone(ZoneInfo("America/New_York"))

def clean_player_name(name):
    """Clean and validate a player name."""
    name = name.strip()
    if len(name) > 100:
        raise ValidationError("Player name too long")
    return name

def validate_unique_player(name, date):
    """Check if a player with the given name already exists."""
    try:
        exists = Player.objects.filter(name__iexact=name).exists()
        if exists:
            raise ValidationError("Player already exists")
    except (OperationalError, DatabaseError) as e:
        logger.error(f"Database error in validate_unique_player: {str(e)}")
        logger.error(traceback.format_exc())
        # Re-raise as ValidationError with a user-friendly message
        raise ValidationError("Unable to validate player name due to database error")
    except Exception as e:
        logger.error(f"Unexpected error in validate_unique_player: {str(e)}")
        logger.error(traceback.format_exc())
        raise ValidationError("An error occurred while validating the player name")

def get_user_stats(user):
    """
    Calculate statistics for a user's picks.
    Returns a dictionary with total_picks, total_wins, and win_percentage.
    """
    logger = logging.getLogger(__name__)
    logger.info(f"Calculating stats for user: {user.username}")
    
    try:
        from .models import DailyPick
        
        # Get all picks for this user
        user_picks = DailyPick.objects.filter(user=user)
        total_picks = user_picks.count()
        logger.info(f"User has {total_picks} total picks")
        
        # Count picks with a winning player set (completed picks)
        completed_picks = user_picks.filter(winning_player__isnull=False).count()
        logger.info(f"User has {completed_picks} completed picks")
        
        # Count winning picks
        winning_picks = user_picks.filter(is_winner=True).count()
        logger.info(f"User has {winning_picks} winning picks")
        
        # Calculate win percentage (avoid division by zero)
        if completed_picks > 0:
            win_percentage = (winning_picks / completed_picks) * 100
        else:
            win_percentage = 0
            
        logger.info(f"User win percentage: {win_percentage:.1f}%")
        
        return {
            'total_picks': total_picks,
            'total_wins': winning_picks,
            'win_percentage': round(win_percentage, 1)
        }
    except Exception as e:
        logger.error(f"Error calculating user stats for {user.username}: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Return default values in case of error
        return {
            'total_picks': 0,
            'total_wins': 0,
            'win_percentage': 0
        }

def calculate_user_stats(user):
    """Calculate total picks, winning picks, and win percentage for a user."""
    try:
        from .models import DailyPick  # Import here to avoid circular import
        
        logger.info(f"Calculating stats for user: {user.username}")
        
        # Test database connection first
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        
        # Get total picks
        total_picks = DailyPick.objects.filter(user=user).count()
        logger.info(f"Total picks for {user.username}: {total_picks}")
        
        # Get winning picks
        winning_picks = DailyPick.objects.filter(user=user, is_winner=True).count()
        logger.info(f"Winning picks for {user.username}: {winning_picks}")
        
        # Calculate win percentage
        win_percentage = (winning_picks / total_picks * 100) if total_picks > 0 else 0
        
        return {
            'total_picks': total_picks,
            'total_wins': winning_picks,
            'win_percentage': round(win_percentage, 1)
        }
    except (OperationalError, DatabaseError) as e:
        # Log database errors specifically
        logger.error(f"Database error in calculate_user_stats for user {user.username}: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            'total_picks': 0,
            'total_wins': 0,
            'win_percentage': 0
        }
    except Exception as e:
        # Log other unexpected errors
        logger.error(f"Unexpected error in calculate_user_stats for user {user.username}: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            'total_picks': 0,
            'total_wins': 0,
            'win_percentage': 0
        }